# QuantumFair Setup

## 1. Requirements
* 64-bit Python 3.11 or 3.12 (the Quantum Rings SDK does not support every version; 3.13 may fail)
* Git

## 2. Create the environment
```bash
cd quantumfair
python3.12 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env              # Windows: copy .env.example .env
```

## 3. Quantum Rings license (do this early, it is the riskiest step)
1. Register / log in at the Quantum Rings portal (quantumrings.com, Login menu).
2. In the portal, open **Manage Keys** and copy your account email and access key.
3. Put them in `.env` as `QR_ACCOUNT_NAME` and `QR_TOKEN`.
4. Uncomment `QuantumRingsLib` in `requirements.txt`, then `pip install -r requirements.txt`.
5. Optional: the SDK can also read a config file:
   * Mac/Linux: `~/.config/quantumrings/quantumrings.conf`
   * Windows: `%APPDATA%\quantumrings\quantumrings.conf`
   ```
   [default]
   email = <YOUR_ACCOUNT_ID>
   key = <YOUR_ACCESS_KEY>
   backend = scarlet_quantum_rings
   ```
6. Confirm the exact calls against the workshop materials before writing the circuit.

## 4. Run
```bash
cd backend
python app.py
```
Open http://localhost:5000

## 5. API contract
| Method | Path | Returns |
|---|---|---|
| GET | `/quantum-draw` | `{ "bits": [...], "source": "quantum", "mock": bool }` |
| GET | `/classical-draw` | `{ "bits": [...], "seed": 1234, "source": "classical" }` |
| POST | `/classical-draw/replay` body `{ "seed": 1234 }` | same bits as the original draw |
| GET | `/stat-test?source=quantum\|classical` | `{ "pass": true, "score": 0.87, ... }` |

`mock` is an extra field so the UI can label placeholder data honestly. Remove it later if you want the contract exact.

## 6. Switching the quantum panel to real
1. Implement `_run_circuit()` in `backend/quantum.py`.
2. Set `QUANTUM_MOCK=false` in `.env`.
3. Restart the server and press Measure twice: the two outputs must differ.
