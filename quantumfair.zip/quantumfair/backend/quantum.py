"""Quantum panel: bits from measuring qubits in superposition on Quantum Rings.

STATUS: placeholder. The real circuit goes in _run_circuit() once the
Quantum Rings license is active and we have confirmed the exact SDK calls
against their docs or workshop materials.
"""
import os
import secrets


def draw(n_bits):
    """Return (bits, is_mock)."""
    if os.getenv("QUANTUM_MOCK", "true").lower() == "true":
        # Placeholder ONLY so the frontend can be built. Not quantum.
        return [secrets.randbits(1) for _ in range(n_bits)], True
    return _run_circuit(n_bits), False


def _run_circuit(n_bits):
    """TODO (build order step 2): replace with the real Quantum Rings circuit.

    Planned shape, to be confirmed against the SDK docs before use:
        provider = QuantumRingsProvider(token=..., name=...)
        backend  = provider.get_backend(os.getenv("QR_BACKEND"))
        qc: n_bits qubits, H gate on every qubit, measure all, 1 shot
        job = backend.run(qc, shots=1); counts = job.result().get_counts()
        the single bitstring in counts -> list of ints
    Do NOT pass any fixed seed option to the simulator, or runs become
    reproducible and the whole contrast breaks.
    """
    raise NotImplementedError("Quantum circuit not wired up yet. Set QUANTUM_MOCK=true.")
