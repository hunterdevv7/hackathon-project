"""Frequency (monobit) chi-square test. No scipy needed."""
import math


def frequency_test(bits, alpha=0.01):
    n = len(bits)
    ones = sum(bits)
    zeros = n - ones
    expected = n / 2
    chi2 = ((ones - expected) ** 2 + (zeros - expected) ** 2) / expected
    p_value = math.erfc(math.sqrt(chi2 / 2))  # chi-square, 1 degree of freedom
    return {"pass": p_value >= alpha, "score": round(p_value, 4),
            "ones": ones, "zeros": zeros}
