"""QuantumFair API. Matches the contract in SETUP.md."""
import os
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS

import classical
import quantum
import stats

load_dotenv(Path(__file__).resolve().parent.parent / ".env")
FRONTEND = Path(__file__).resolve().parent.parent / "frontend"
BATCH = int(os.getenv("BATCH_SIZE", "64"))

app = Flask(__name__)
CORS(app)


@app.get("/")
def index():
    return send_from_directory(FRONTEND, "index.html")


@app.get("/quantum-draw")
def quantum_draw():
    bits, is_mock = quantum.draw(BATCH)
    return jsonify({"bits": bits, "source": "quantum", "mock": is_mock})


@app.get("/classical-draw")
def classical_draw():
    bits, seed = classical.draw(BATCH)
    return jsonify({"bits": bits, "seed": seed, "source": "classical"})


@app.post("/classical-draw/replay")
def classical_replay():
    body = request.get_json(silent=True) or {}
    if "seed" not in body:
        return jsonify({"error": "seed is required"}), 400
    bits, seed = classical.draw(BATCH, seed=int(body["seed"]))
    return jsonify({"bits": bits, "seed": seed, "source": "classical"})


@app.get("/stat-test")
def stat_test():
    source = request.args.get("source", "quantum")
    if source == "quantum":
        bits, _ = quantum.draw(BATCH)
    elif source == "classical":
        bits, _ = classical.draw(BATCH)
    else:
        return jsonify({"error": "source must be quantum or classical"}), 400
    return jsonify({**stats.frequency_test(bits), "source": source, "n": len(bits)})


if __name__ == "__main__":
    app.run(debug=True, port=int(os.getenv("FLASK_PORT", "5000")))
