"""Classical panel: a seeded PRNG that can be replayed exactly (the "hack")."""
import random
import secrets


def draw(n_bits, seed=None):
    """Return (bits, seed). Same seed always gives the same bits."""
    if seed is None:
        seed = secrets.randbelow(10_000)  # small seed space on purpose: it is the weakness we demo
    rng = random.Random(seed)
    bits = [rng.getrandbits(1) for _ in range(n_bits)]
    return bits, seed
